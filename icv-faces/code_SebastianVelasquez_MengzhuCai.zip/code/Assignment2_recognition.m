%% Part I: Face Recognition: Who is it?
%==========================================================================
% This is the evaluation part of face verification in assignment2 Part1
% Feature extraction and classifier training are implemented in Python
% file:
%   face_recognition.py: Definition of model and feature extraction
%   common.py: Utility functions for feature extraction and prediction
% Features: HoG + LBP
% Classifier: SVM
% Weights and bias calculated by SVM classifier and features of testing
% dataset are imported by Python
%==========================================================================

run ICV_setup
disp('Recognition...')

%labels of testing and training images
Yva = [];
Ytr = [];

%load training and testing dataset
load('./data/face_recognition/face_recognition_data_tr.mat')
load('./data/face_recognition/face_recognition_data_te.mat')

%get labels of testing and training images
for i =1:length(tr_img_sample)
    Ytr = [Ytr;tr_img_sample{i,3}];
end
for i =1:length(va_img_sample)
    Yva = [Yva;va_img_sample{i,3}];
end

%% import parameters
temp = csvread('face_recognition_w_b.txt');
Xva = csvread('face_recognition_test.txt');
Xva(:,1) = [];
B = temp(:,1);
W = temp(:,2:end);
Xva = double(Xva);

% score for every classes
classes = unique(Ytr);
temp = size(classes);
class_size = temp(1,1);
eva = [];
score = [];

for i = 1:class_size
    w = W(i,:)';
    score_temp = Xva*w+B(i);
    score = [score,score_temp];
end

%% calculate accuracy
[~,score_max] = max(score,[],2);
eva = (score_max == Yva);
prob2 = 1./(1+exp(-score)); 
 
  

% Compute the accuracy
acc = mean(eva)*100;

fprintf('The accuracy of face recognition is:%.2f \n', acc)
% Check your result on the raw images and try to analyse the limits of the
% current method.


%% Visualization the result of face recognition

data_idx = [1,30,50]; % The index of image in validation set
nSample = 3; % number of visualize data. maximum should be 3
% nPairs = length(data_idx); % unconment to get full size of 
visualise_recognition(va_img_sample,prob2,Yva,data_idx,nSample )