%====================================================
%This is a function implementing HoG methods with unrecognized problem
%====================================================

function features = hog(image,cellSize,orientation,block)

%computation of the gradient values and magnitude
filter = [-1,0,1];
gra_h = filter2(filter,image,'same');
gra_v = filter2(filter',image,'same');
magnitude = sqrt(gra_h.^2 + gra_v.^2);

direction = zeros(size(gra_h));
index=gra_h&gra_v;
direction(index) = atand(gra_h(index)./gra_v(index));

index = gra_h&~(gra_v);
direction(index) = 0;
magnitude(index) = 0;

index = gra_v&~(gra_h);
direction(index) = gra_v(index);

%unsigned
direction = (direction + 90);

%get histogram of gradients with cellSize
cells_mag = [];
cells_dir = [];
for j =1:(size(image,1)/cellSize)
    for i =1:(size(image,2)/cellSize)
        index_x = (i-1)*cellSize+1;
        index_y = (j-1)*cellSize+1;
        mag = magnitude(index_x:index_x+cellSize-1,index_y:index_y+cellSize-1);
        dir = direction(index_x:index_x+cellSize-1,index_y:index_y+cellSize-1);
        cells_mag = [cells_mag;mag(:)'];
        cells_dir = [cells_dir;dir(:)'];
    end
end

step = 180/orientation;
degrees = [0:step:180-step];
histogram = zeros(size(cells_mag,1),size(degrees,2));
for k = 1:length(cells_mag)
    temp_mag = cells_mag(k,:);
    temp_dir = cells_dir(k,:);
    for i = 1:size(temp_mag,2)
        distance = abs(degrees-temp_dir(i));
        [sorting,index] = sort(distance,'ascend');
        if (double(sorting(1))==0)
            histogram(k,index(1)) = histogram(k,index(1))+temp_mag(i);
        else
            if((temp_dir(i)>180-step)&&(sorting(1)~=0))
                histogram(k,1) = histogram(k,1)+temp_mag(i)*(abs(temp_dir(i)-degrees(end)/step));
                histogram(k,end) = histogram(k,end) + temp_mag(i)*(abs(temp_dir(i)-degrees(1)/step));
            else
                histogram(k,index(1)) = histogram(k,index(1))+temp_mag(i)*(abs(temp_dir(i)-degrees(index(2)))/step);
                histogram(k,index(2)) = histogram(k,index(2))+temp_mag(i)*(abs(temp_dir(i)-degrees(index(1)))/step);
            end
        end
    end
end

%block normalization
cell_per_block = (block/cellSize)^2;
block_norm = [];
for k = 1:size(histogram,1)/cell_per_block
    times = (k-1)*cell_per_block;
    block_vector = [];
    for i = 1:cell_per_block
        block_vector = [block_vector,histogram(times+i,:)];
    end 
    block_norm = [block_norm;(block_vector./norm(block_vector))];
end

features = block_norm(:)';