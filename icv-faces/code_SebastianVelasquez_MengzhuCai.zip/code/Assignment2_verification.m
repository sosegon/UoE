%% Part II: Face Verification: 
%==========================================================================
% This is the evaluation part of face verification in assignment2 Part2
% Feature extraction and classifier training are implemented in Python
% file:
%   face_verification.py: Definition of model and feature extraction
%   common.py: Utility functions for feature extraction and prediction
% Features: HoG
% Classifier: SVM
% The weights, bias for classfying and features of testing images 
% are imported from Python
%==========================================================================

%% Import data
run ICV_setup
disp('Verification...')


Xva = []; %features of testing images

%loading testing dataset
load('./data/face_verification/face_verification_te.mat')

%import weights and bias of classifier
temp = csvread('verification_w_b.txt');

%import features of testing images
Xva = csvread('face_verification_test.txt');
Xva(:,1) = [];      %discard the first label column
b = temp(end);      %get bias
w = temp(1:end-1);  %get weights


%% Calculate accuracy
score = Xva*w + b;          %get scores of each testing image
prob2 = 1./(1+exp(-score)); %calculate probability of same person
prob = [1-prob2, prob2];  

%same people is 1, different people is -1
l = (prob2>0.5);            
l = double(l);
l(l==0)=-1;

% Compute the accuracy
acc = mean(l==Yva)*100;

fprintf('The accuracy of face recognition is:%.2f \n', acc)



%% Visualization the result of face verification

data_idx = [100,200,300]; % The index of image in validation set
nPairs = 3; % number of visualize data. maximum is 3
% nPairs = length(data_idx); 
visualise_verification(va_img_pair,prob,Yva,data_idx,nPairs )