% Image and Visual Computing Assignment 1: Face Detection-Recognition
%==========================================================================

%% Initialisation
%==========================================================================
% Add the path of used library.
% - The function of adding path of liblinear and vlfeat is included.
% - The use image directory is also included in this part.
% - image_dir{1} is the training positive face images(resize).
% - image_dir{2} is the training negative non-face images(resize).
% - val_dir is the validation set of real images
%==========================================================================
clear all
clc
run ICV_setup
% The relevant data directory
images_dir{1} = './data/face_detection/cropped_faces/';     % positive samples directory
images_dir{2} = './data/face_detection/non_faces_images/';  % negative samples directory
face_images_dir = dir(images_dir{1});
face_images_dir(1:2)=[];

val_dir{1} = './data/face_detection/val_face_detection_images/'; % Validation data (For visualization purpose).
val_file = dir(val_dir{1});
val_file(1:2)=[];
val_dir{2} = './data/face_detection/val_raw_images/';            % Validation data (For performance evaluation)
val_file2 = dir(val_dir{2});
val_file2(1:2)=[];

% Hyperparameter of experiments
resize_size=[64 64];


%% Feature Extraction for Face Detection
%==========================================================================
% Use HoG+LBP for feature extraction
%==========================================================================

% Feature Extraction

disp('Extracting features...')

Xtr = [];
Lbp = [];
% Read and Resize the face images. Extract the features here.
cellSize = 8;
%nFace = 25; 
nFace = length(face_images_dir);  % Uncomment it to get more training data
parfor i=1:nFace                     % Uncomment it to try parallel for-loop to speed up the experiments
%for i=1:nFace
    temp = imresize(imread([images_dir{1},face_images_dir(i).name]),resize_size);
    temp = single(temp)/255;
    temp1 = vl_lbp(temp,8);
    %temp = hog(temp,cellSize,9,16);
    temp = vl_hog(temp,cellSize,'numOrientations',9);
    Xtr = [Xtr;temp(:)'];
    Lbp = [Lbp;temp1(:)'];
end

% load non_face_images
non_face_images_dir = dir(images_dir{2});
non_face_images_dir(1:2)=[];
count = 0;
imset = imageSet(images_dir{2}, 'recursive');

% Read and Resize the non-face images. Extract the features here.
for i=1:length(imset)
    parfor j = 1:imset(i).Count     % Uncomment it to get more training data
%    for j = 1:min(imset(i).Count,25)
        count = count+1;
        temp = imresize(read(imset(i),j),resize_size);
        if size(temp,3)>1, temp = rgb2gray(temp); end
        temp = single(temp)/255;
        temp1 = vl_lbp(temp,8);
        %temp = hog(temp,cellSize,9,16);
        temp = vl_hog(temp,cellSize,'numOrientations',9);
        Xtr = [Xtr;temp(:)'];
        Lbp = [Lbp;temp1(:)'];
    end
end
 

Xtr = [Xtr,Lbp];
% Create the labelled image
Ytr = [ones(nFace,1);-1*ones(count,1)];


%% Training the Face Detector
%==========================================================================
% use SVM as classifier
% sliding window: from left to right, up to down, based on scale and stride
%==========================================================================

disp('Training the face detector..')

lambda = 0.01; %learning parameters
maxIter = 1000; %Maximum number of iterations
[w,b,info] = vl_svmtrain(Xtr',Ytr,lambda,'MaxNumIterations',maxIter);

% save trained model for evaluation.
save face_detector w b;

%% Single/Multi-Scale Sliding Window
%load('face_detector.mat')
for k=1:length(val_file)
    img = imread([val_dir{1} val_file(k).name]);
    plt_img=img;
    if size(img,3)>1, img = rgb2gray(img); end
    window_size=[64 64];
    
    % sliding window
    [patches,temp_bbox] = sw_detect_face(img,window_size,1,32);    
    
    Xte=[];
    Lbp1 = [];
    bbox_ms = [];
    % Extract the feature for each patch
    for p=1:length(patches)
        for j = 1:size(patches{p},3)
            face_img = single(patches{p}(:,:,j))/255;
            face_img1 = vl_lbp(face_img,8);
            face_img = vl_hog(face_img,cellSize,'numOrientations',9);
            %face_img = hog(face_img,cellSize,9,16);
            Xte = [Xte; face_img(:)'];
            Lbp1 = [Lbp1;face_img1(:)'];
            bbox_ms = [bbox_ms;temp_bbox{p}(j,:)];
        end
    end
    Xte = [Xte,Lbp1];
    
    % Get score
    score = Xte*w + b;

    % Setting a threshold to pick the proposed face images
    threshold = 0.5;
    threshold_bbox=bbox_ms(score>threshold,:);
    prob3=score(score>threshold);

    % Remove the redundant boxes via non-maximum supression.
    % - The bbox is the top-left x,y, height,width of the patches.
    % - prob3 is the confidence of the patches
    [selectedBbox,selectedScore] = selectStrongestBbox(threshold_bbox,prob3,'OverlapThreshold',0.3, 'RatioType','Union');

    % Visualise the test images
    bbox_position = selectedBbox;
    figure
    imshow(plt_img)
    hold on
    for i=1:size(bbox_position,1)
    rectangle('Position', [bbox_position(i,2),bbox_position(i,1),bbox_position(i,3:4)],...
        'EdgeColor','b', 'LineWidth', 3)
    
    % This is the bounding box of ground truth. You should not modify this
    % part
    %======================================================================
    rectangle('Position', [83,92,166-83,175-92],...
        'EdgeColor','r', 'LineWidth', 3)
    %======================================================================
    end
    saveas(gcf, [val_file(k).name(1:end-4),'_sw64.png'])
    clear Xte Yte
end


%% Evaluating your result on the val_datasets

run ICV_setup % add the library path
load('face_detector.mat') % load your pretrained model

% Initialization of the true positive, condition positive and prediction
% positive number collection.

val_dir{2} = './data/face_detection/te_raw_images/';            % Test data (For performance evaluation)
val_file2 = dir(val_dir{2});
val_file2(1:2)=[];

total_TP = zeros(length(val_file2),100);
total_condi_P = zeros(length(val_file2),100);
total_Pred_P = zeros(length(val_file2),100);



imset = imageSet(val_dir{2}, 'recursive');
count = 0;

for k=1:length(val_file2)
    
    
    for j = 1:length(imset(k).Count)
        count = count+1;
        img = read(imset(k),j);
        plt_img=img;
        if size(img,3)>1, img = rgb2gray(img); end
        window_size=[64 64];

        % Use sliding window to get multiple patches from the original image
        [patches,temp_bbox] = sw_detect_face(img,window_size,1,32);    
        Xte=[];
        Lbp1 = [];
        bbox_ms = [];

        % Extract your features here
        for p=1:length(patches)
            for j = 1:size(patches{p},3)
                face_img = single(patches{p}(:,:,j))/255;
                face_img1 = vl_lbp(face_img,8);
                %face_img = hog_feature_vector(face_img);
                face_img = vl_hog(face_img,cellSize,'numOrientations',9);
                %face_img = hog(face_img,cellSize,9,16);
                Xte = [Xte; face_img(:)'];
                Lbp1 = [Lbp1;face_img1(:)'];
                bbox_ms = [bbox_ms;temp_bbox{p}(j,:)];
            end
        end
        Xte = [Xte,Lbp1];
        % Get the positive probability
        %Xte = Xte';
        %[~,~,d] = liblinearpredict(ones(size(Xte,1),1),sparse(double(Xte)),detector);
        score = Xte*w + b;
        prob2 = 1./(1+exp(-score));
        prob = [1-prob2, prob2];
 
        %prob = 1/(1+exp((0.01*score-0.5)));

        %[~,score] = predict(Mdl,Xte);
        %prob2 = score(:,2);
        %temp = score(score>0.2)';
    
        % Getting the True positive, condition positive, predicted positive
        % number for evaluating the algorithm performance via Average 
        [ TP_num, condi_P, Pred_P ] = evaluate_detector( bbox_ms, prob2 );
        total_TP(count,:) = TP_num;
        total_condi_P(count,:) = condi_P;
        total_Pred_P(count,:) = Pred_P;
        clear Xte Yte
    end
end


% Summing the statistics over all faces images.
sTP = sum(total_TP);
sCP = sum(total_condi_P);
sPP = sum(total_Pred_P);

% Compute the Precision
% TP is the number of intersection betweem recognized faces and the
% actual faces
sPP(sPP==0) = 1;            %171123 add by cmz
Precision = sTP./sPP;       % TP/(The number of recognized faces)
Recall = sTP./sCP;          % TP/(The number of actual faces)

% Ploting the Precision-Recall curve. Normally, the yaxis is the Precision
% and xaxis is the Recall.
figure
plot(Recall, Precision)
xlabel('Recall');
ylabel('Precision');


% Average Precision
AP = VOCap(Recall', Precision');
disp(num2str(AP))
