% Image and Visual Computing Assignment 1: Face Detection
%==========================================================================
% Feature extraction and classifier training are implemented in Python
% file:
%   face_detectionsvm_train.py: Definition of model and feature extraction
%   common.py: Utility functions for feature extraction and prediction
% Features: HoG
% Classifier: SVM
% Weights and bias calculated by SVM classifier and features of testing
% dataset are imported from Python
%==========================================================================
%% Loading parameters
temp1 = csvread('face_detection_w_b.txt');
Image_data = csvread('face_detection_test.txt');
temp = temp1';

w = temp(1:end-1,:);
b = temp(end,:);

image_num = length(unique(Image_data(:,1)));

%% Evaluating your result on the val_datasets

run ICV_setup % add the library path

% The test set
val_dir{2} = './data/face_detection/te_raw_images/';            % Test data (For performance evaluation)
val_file2 = dir(val_dir{2});
val_file2(1:2)=[];

% % The validation set
% val_dir{2} = './data/face_detection/val_raw_images/';            % Validation data (For performance evaluation)
% val_file2 = dir(val_dir{2});
% val_file2(1:2)=[];

% Initialization of the true positive, condition positive and prediction
% positive number collection.

total_TP = zeros(length(val_file2),100);
total_condi_P = zeros(length(val_file2),100);
total_Pred_P = zeros(length(val_file2),100);



imset = imageSet(val_dir{2}, 'recursive');
count = 0;
step = 1;
for k=0:image_num-1
    patches = Image_data(Image_data(:,1)==k,:);
    patches(:,1) = [];
    count = count + 1;
    bbox_ms = [];
    Xte = [];
    bbox_ms = patches(:,1:4);
    Xte = patches(:,5:end);
    % Get the positive probability
    score = Xte*w+b;
    prob2 = 1./(1+exp(-score));
    prob = [1-prob2, prob2];
    
    % Getting the True positive, condition positive, predicted positive
    % number for evaluating the algorithm performance via Average 
    [ TP_num, condi_P, Pred_P ] = evaluate_detector( bbox_ms, prob2 );
    total_TP(count,:) = TP_num;
    total_condi_P(count,:) = condi_P;
    total_Pred_P(count,:) = Pred_P;
    step = step + length(patches)-1;
end


% Summing the statistics over all faces images.
sTP = sum(total_TP);
sCP = sum(total_condi_P);
sPP = sum(total_Pred_P);

% Compute the Precision
% TP is the number of intersection betweem recognized faces and the
% actual faces

Precision = sTP./sPP;       % TP/(The number of recognized faces)
Recall = sTP./sCP;          % TP/(The number of actual faces)

% Ploting the Precision-Recall curve. Normally, the yaxis is the Precision
% and xaxis is the Recall.
figure
plot(Recall, Precision)
xlabel('Recall');
ylabel('Precision');


% Interpolated Average Precision
AP = VOCap(Recall', Precision');
disp(num2str(AP))